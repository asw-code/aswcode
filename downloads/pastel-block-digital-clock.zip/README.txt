Pastel Block Digital Clock

A stylish and responsive digital clock built with HTML, CSS, and JavaScript.
It features a soft pastel block design for hours, minutes, and seconds, with a blinking colon for a modern and minimal look.

Features
- Real-time digital clock with blinking colon animation
- Pastel color blocks for hours, minutes, and seconds
- Fully responsive layout for all screen sizes
- Simple and clean UI using pure HTML, CSS, and JavaScript
- Lightweight and easy to customize

Usage
- Download and unzip the folder.
- Open the file named pastel-block-digital-clock.html in your browser.
- View the live digital clock instantly.

License

This project is free to use for educational and personal purposes.
Redistribution, modification for commercial use, or resale without permission is strictly prohibited.

Author

Created by ASWCode
Visit: aswcode.com