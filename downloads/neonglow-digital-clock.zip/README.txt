NeonGlow Digital Clock

A stylish and responsive digital clock built with HTML, CSS, and JavaScript.
It features a glowing neon design and smooth animations for a modern look.

Features:
- Real-time digital clock with blinking colon animation
- Neon glow and gradient background design
- Fully responsive layout for all screen sizes
- Simple and clean UI using pure HTML, CSS, and JavaScript
- Lightweight and easy to customize

Usage:
- Download and unzip the folder.
- Open the file named neonglow-digital-clock.html in your browser.
- View the live digital clock instantly.

License:
This project is free to use for educational and personal purposes.
Redistribution, modification for commercial use, or resale without permission is strictly prohibited.

Author:
Created by ASWCode
Visit: aswcode.com