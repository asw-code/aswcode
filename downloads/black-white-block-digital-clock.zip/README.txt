Black & White Block Digital Clock

A minimalist and responsive digital clock built with HTML, CSS, and JavaScript.
It features a clean black-and-white block design with sharp edges and smooth transitions — perfect for modern, professional layouts.

Features
- Real-time digital clock with live updates every second
- Minimal black-and-white theme for a clean aesthetic
- Fully responsive design for all screen sizes (desktop, tablet, mobile)
- Built with pure HTML, CSS, and JavaScript — no frameworks required
- Lightweight, fast-loading, and easy to customize

Usage
- Download and unzip the project folder.
- Open the file named black-white-block-digital-clock.html in your browser.
- View the live digital clock instantly.

License

This project is free to use for educational and personal purposes.
Redistribution, modification for commercial use, or resale without permission is strictly prohibited.

Author

Created by ASWCode
Visit: aswcode.com